/* Automatically generated; do not edit */
#ifndef _OPT_NETFS_H_
#define _OPT_NETFS_H_
#define OPT_NETFS 0
#endif /* _OPT_NETFS_H_ */
