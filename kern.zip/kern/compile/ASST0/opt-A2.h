/* Automatically generated; do not edit */
#ifndef _OPT_A2_H_
#define _OPT_A2_H_
#define OPT_A2 0
#endif /* _OPT_A2_H_ */
