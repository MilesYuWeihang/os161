/* Automatically generated; do not edit */
#ifndef _OPT_A0_H_
#define _OPT_A0_H_
#define OPT_A0 0
#endif /* _OPT_A0_H_ */
